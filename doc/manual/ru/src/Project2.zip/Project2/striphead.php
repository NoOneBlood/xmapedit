<?php
$dir = scandir(".");

function qprintr($a)
{
    echo '<pre>'.$a.'</pre>';
}

foreach ($dir as $f)
{
    $i = pathinfo($f);
    if ($i['extension'] != 'html')
        continue;
    
    $file = file_get_contents($f);
    
    $lt = strripos($file, "<title>");
    $rt = stripos($file, "</title>");
    
    $title = substr($file, $lt+strlen("<title>"), $rt-$lt-strlen("<title>"));

    qprintr($title);
    
}
//$file = file_get_contents("project2/2installation.html");

//$f = strripos($file, "<title>");
//$l = stripos($file, "</title>");

//$title = substr($file, $f+strlen("<title>"), $l-$f-strlen("<title>"));

//$pat = "/^<title>/i";

//preg_match($pat, $file, $match);
//print_r($title);

?>